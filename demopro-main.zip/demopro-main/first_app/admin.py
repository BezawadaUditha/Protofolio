from django.contrib import admin
from first_app.models import Contact
from first_app.models import Contact2
from first_app.models import Res

# Register your models here.
admin.site.register(Contact)
admin.site.register(Contact2)
admin.site.register(Res)
